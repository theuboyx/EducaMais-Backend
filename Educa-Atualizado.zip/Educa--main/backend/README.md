# API Educa+

Express + TypeScript + Prisma + PostgreSQL.

## Configuração
Copie `.env.example` para `.env`, configure `DATABASE_URL` e `JWT_SECRET`, depois:

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run dev
```

Para criar usuários de demonstração: `npx prisma db seed` (aluno: `aluna@educamais.test`; professor: `professor@educamais.test`; senha de ambos: `Senha@123`).

## Recuperação de senha
Configure `RESEND_API_KEY`, `EMAIL_FROM` e `APP_RESET_URL`. Sem Resend, em desenvolvimento o link/token é apresentado para teste local; nunca use essa configuração em produção.

## Endpoints
`POST /auth/register`, `POST /auth/login`, `GET /auth/me`, `GET /auth/student`, `GET /auth/teacher`, `POST /auth/forgot-password`, `POST /auth/reset-password`.
