import assert from "node:assert/strict";
import type { AddressInfo } from "node:net";
import { after, before, describe, it } from "node:test";
import type { Server } from "node:http";
import app from "../src/app";
import { signAccessToken, verifyAccessToken } from "../src/lib/tokens";

let server: Server;
let baseUrl: string;
const hasDatabase = Boolean(process.env.DATABASE_URL);

before(async () => {
  await new Promise<void>((resolve) => {
    server = app.listen(0, "127.0.0.1", resolve);
  });
  baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(() => { server.close(); });

async function post(path: string, body: unknown, raw = false) {
  const res = await fetch(baseUrl + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: raw ? (body as string) : JSON.stringify(body),
  });
  return { status: res.status, json: await res.json() as any };
}

const validRegister = {
  role: "aluno", name: "Maria Silva", email: `maria-${Date.now()}@exemplo.com`, password: "senha1234",
};

describe("GET /health", () => {
  it("responde 200 com status ok", async () => {
    const res = await fetch(baseUrl + "/health");
    const json = await res.json() as any;
    assert.equal(res.status, 200);
    assert.equal(json.status, "ok");
  });
});

describe("validação de cadastro", () => {
  it("corpo vazio retorna 400 com todos os campos", async () => {
    const { status, json } = await post("/auth/register", {});
    assert.equal(status, 400);
    assert.equal(json.error.code, "VALIDATION_ERROR");
    assert.deepEqual(Object.keys(json.error.fields).sort(), ["email", "name", "password", "role"]);
  });

  it("senha curta retorna 400", async () => {
    const { status, json } = await post("/auth/register", { ...validRegister, password: "1234567" });
    assert.equal(status, 400);
    assert.ok(json.error.fields.password);
  });

  it("perfil inválido retorna 400", async () => {
    const { status, json } = await post("/auth/register", { ...validRegister, role: "admin" });
    assert.equal(status, 400);
    assert.ok(json.error.fields.role);
  });

  it("e-mail inválido retorna 400", async () => {
    const { status, json } = await post("/auth/register", { ...validRegister, email: "maria@" });
    assert.equal(status, 400);
    assert.ok(json.error.fields.email);
  });

  it("JSON malformado retorna 400 INVALID_JSON", async () => {
    const { status, json } = await post("/auth/register", "{nao-e-json", true);
    assert.equal(status, 400);
    assert.equal(json.error.code, "INVALID_JSON");
  });
});

describe("autenticação", () => {
  it("cria e valida token assinado", () => {
    process.env.JWT_SECRET = "chave-de-teste-com-pelo-menos-trinta-e-dois-caracteres";
    const token = signAccessToken({ sub: "user-123", email: "teste@exemplo.com", role: "aluno" });
    const payload = verifyAccessToken(token);
    assert.equal(payload.sub, "user-123");
    assert.equal(payload.role, "aluno");
  });

  it("rejeita token adulterado", () => {
    process.env.JWT_SECRET = "chave-de-teste-com-pelo-menos-trinta-e-dois-caracteres";
    assert.throws(() => verifyAccessToken("a.b.c"), /Token inválido/);
  });

  it("sem token a rota protegida responde 401", async () => {
    const res = await fetch(baseUrl + "/auth/me");
    const json = await res.json() as any;
    assert.equal(res.status, 401);
    assert.equal(json.error.code, "AUTHENTICATION_REQUIRED");
  });

  it("aluno não acessa a rota exclusiva de professor", async () => {
    process.env.JWT_SECRET = "chave-de-teste-com-pelo-menos-trinta-e-dois-caracteres";
    const token = signAccessToken({ sub: "student-1", email: "aluno@teste.com", role: "aluno" });
    const res = await fetch(baseUrl + "/auth/teacher", { headers: { Authorization: `Bearer ${token}` } });
    assert.equal(res.status, 403);
  });

  it("professor acessa sua rota exclusiva", async () => {
    process.env.JWT_SECRET = "chave-de-teste-com-pelo-menos-trinta-e-dois-caracteres";
    const token = signAccessToken({ sub: "teacher-1", email: "prof@teste.com", role: "professor" });
    const res = await fetch(baseUrl + "/auth/teacher", { headers: { Authorization: `Bearer ${token}` } });
    const json = await res.json() as any;
    assert.equal(res.status, 200);
    assert.equal(json.profile, "professor");
  });
});

describe("integração com PostgreSQL", { skip: !hasDatabase }, () => {
  it("cadastra um usuário no banco", async () => {
    const { status, json } = await post("/auth/register", validRegister);
    assert.equal(status, 201);
    assert.equal(json.user.email, validRegister.email);
    assert.equal(json.user.role, "aluno");
  });

  it("login devolve token de acesso", async () => {
    const { status, json } = await post("/auth/login", {
      email: validRegister.email, password: validRegister.password,
    });
    assert.equal(status, 200);
    assert.ok(json.accessToken);
    assert.equal(json.user.role, "aluno");
  });
});
