import type { RequestHandler } from "express";
import { AppError } from "../errors/AppError";
import { verifyAccessToken, type TokenRole } from "../lib/tokens";

declare global {
  namespace Express {
    interface Request {
      auth?: { sub: string; email: string; role: TokenRole; iat: number; exp: number };
    }
  }
}

export const authenticate: RequestHandler = (req, _res, next) => {
  try {
    const authorization = req.header("authorization");
    if (!authorization?.startsWith("Bearer ")) {
      throw new AppError(401, "AUTHENTICATION_REQUIRED", "Informe um token de acesso.");
    }
    req.auth = verifyAccessToken(authorization.slice(7).trim());
    next();
  } catch (error) {
    next(error);
  }
};

export function authorize(...roles: TokenRole[]): RequestHandler {
  return (req, _res, next) => {
    if (!req.auth) {
      next(new AppError(401, "AUTHENTICATION_REQUIRED", "Faça login para continuar."));
      return;
    }
    if (!roles.includes(req.auth.role)) {
      next(new AppError(403, "FORBIDDEN", "Você não tem permissão para acessar este recurso."));
      return;
    }
    next();
  };
}
