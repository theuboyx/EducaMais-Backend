import { Router } from "express";
import { forgotPassword, login, me, register, resetPassword } from "../controllers/auth.controller";
import { authenticate, authorize } from "../middlewares/auth.middleware";

const router = Router();

router.post("/register", register);
router.post("/login", login);
router.post("/forgot-password", forgotPassword);
router.post("/reset-password", resetPassword);
router.get("/me", authenticate, me);
router.get("/student", authenticate, authorize("aluno"), (_req, res) => res.json({ profile: "aluno" }));
router.get("/teacher", authenticate, authorize("professor"), (_req, res) => res.json({ profile: "professor" }));

export default router;
