import "dotenv/config";
import { PrismaClient } from "../generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

// O fallback permite importar a aplicação para executar testes de validação
// sem banco. Para uso real, DATABASE_URL deve estar configurada no .env.
const connectionString = process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/educa";
const adapter = new PrismaPg({ connectionString });

export const prisma = new PrismaClient({ adapter });
