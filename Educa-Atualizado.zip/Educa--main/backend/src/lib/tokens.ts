import { createHmac, timingSafeEqual } from "node:crypto";
import { AppError } from "../errors/AppError";

export type TokenRole = "aluno" | "professor";
export type AccessTokenPayload = { sub: string; email: string; role: TokenRole; iat: number; exp: number };

const secret = () => {
  const value = process.env.JWT_SECRET;
  if (!value || value.length < 32) {
    throw new Error("JWT_SECRET deve existir e ter pelo menos 32 caracteres.");
  }
  return value;
};

const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString("base64url");

export function signAccessToken(input: Pick<AccessTokenPayload, "sub" | "email" | "role">): string {
  const now = Math.floor(Date.now() / 1000);
  const expiresIn = Number(process.env.JWT_EXPIRES_IN_SECONDS || 3600);
  const header = encode({ alg: "HS256", typ: "JWT" });
  const payload = encode({ ...input, iat: now, exp: now + expiresIn });
  const data = `${header}.${payload}`;
  const signature = createHmac("sha256", secret()).update(data).digest("base64url");
  return `${data}.${signature}`;
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  const parts = token.split(".");
  if (parts.length !== 3) throw new AppError(401, "INVALID_TOKEN", "Token inválido.");
  const [header, payload, signature] = parts;
  const expected = createHmac("sha256", secret()).update(`${header}.${payload}`).digest();
  let actual: Buffer;
  try { actual = Buffer.from(signature, "base64url"); } catch {
    throw new AppError(401, "INVALID_TOKEN", "Token inválido.");
  }
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) {
    throw new AppError(401, "INVALID_TOKEN", "Token inválido.");
  }
  try {
    const decodedHeader = JSON.parse(Buffer.from(header, "base64url").toString());
    const decoded = JSON.parse(Buffer.from(payload, "base64url").toString()) as AccessTokenPayload;
    if (decodedHeader.alg !== "HS256" || !decoded.sub || !decoded.email ||
        !["aluno", "professor"].includes(decoded.role) || decoded.exp <= Math.floor(Date.now() / 1000)) {
      throw new Error("invalid claims");
    }
    return decoded;
  } catch {
    throw new AppError(401, "INVALID_TOKEN", "Token inválido ou expirado.");
  }
}
