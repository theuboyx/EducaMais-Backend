import express from "express";
import { errorHandler, notFoundHandler } from "./middlewares/errorHandler";
import authRoutes from "./routes/auth.routes";
import healthRoutes from "./routes/health.routes";

const app = express();

app.use(express.json());

// Permite chamadas do Expo Web; apps nativos não dependem de CORS.
// Em produção, defina FRONTEND_ORIGIN com o domínio exato do aplicativo web.
app.use((req, res, next) => {
  const origin = process.env.FRONTEND_ORIGIN || "*";
  res.header("Access-Control-Allow-Origin", origin);
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") {
    res.sendStatus(204);
    return;
  }
  next();
});

app.use("/health", healthRoutes);
app.use("/auth", authRoutes);

// A ordem importa: 404 e tratamento de erros vêm DEPOIS de todas as rotas.
app.use(notFoundHandler);
app.use(errorHandler);

export default app;
