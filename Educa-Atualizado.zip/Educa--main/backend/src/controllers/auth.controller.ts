import type { RequestHandler } from "express";
import bcrypt from "bcryptjs";
import { createHash, randomBytes } from "node:crypto";
import { AppError } from "../errors/AppError";
import { prisma } from "../lib/prisma";
import { signAccessToken } from "../lib/tokens";
import {
  validateForgotPassword,
  validateLogin,
  validateRegister,
  validateResetPassword,
} from "../validation/auth.validation";

const ROLE_TO_DB = { aluno: "STUDENT", professor: "TEACHER" } as const;
const ROLE_FROM_DB = { STUDENT: "aluno", TEACHER: "professor" } as const;

export const register: RequestHandler = async (req, res, next) => {
  try {
    const { role, name, email, password } = validateRegister(req.body);
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { name, email, passwordHash, role: ROLE_TO_DB[role] },
      select: { id: true, name: true, email: true, role: true },
    });
    res.status(201).json({ user: { ...user, role: ROLE_FROM_DB[user.role] } });
  } catch (err) {
    if ((err as { code?: string })?.code === "P2002") {
      next(new AppError(409, "EMAIL_ALREADY_EXISTS", "Este e-mail já está cadastrado.", {
        email: "Este e-mail já está cadastrado.",
      }));
      return;
    }
    next(err);
  }
};

export const login: RequestHandler = async (req, res, next) => {
  try {
    const { email, password } = validateLogin(req.body);
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      throw new AppError(401, "INVALID_CREDENTIALS", "E-mail ou senha incorretos.");
    }

    const role = ROLE_FROM_DB[user.role];
    const accessToken = signAccessToken({ sub: user.id, email: user.email, role });
    res.json({
      accessToken,
      tokenType: "Bearer",
      expiresIn: Number(process.env.JWT_EXPIRES_IN_SECONDS || 3600),
      user: { id: user.id, name: user.name, email: user.email, role },
    });
  } catch (err) {
    next(err);
  }
};

export const me: RequestHandler = async (req, res, next) => {
  try {
    const userId = req.auth!.sub;
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, email: true, role: true, avatarUrl: true, totalPoints: true },
    });
    if (!user) throw new AppError(401, "USER_NOT_FOUND", "Conta não encontrada.");
    res.json({ ...user, role: ROLE_FROM_DB[user.role] });
  } catch (err) {
    next(err);
  }
};

async function sendResetEmail(email: string, resetUrl: string): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!apiKey || !from) {
    if (process.env.NODE_ENV === "production") {
      console.error("Recuperação de senha sem RESEND_API_KEY/EMAIL_FROM configurados.");
      return;
    }
    console.info(`[Educa+] Link de recuperação para ${email}: ${resetUrl}`);
    return;
  }

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [email],
      subject: "Redefinição de senha - Educa+",
      html: `<p>Recebemos uma solicitação para redefinir sua senha.</p><p><a href="${resetUrl}">Redefinir senha</a></p><p>O link expira em 30 minutos. Se não foi você, ignore esta mensagem.</p>`,
    }),
  });
  if (!response.ok) throw new AppError(502, "EMAIL_SEND_FAILED", "Não foi possível enviar o e-mail agora.");
}

export const forgotPassword: RequestHandler = async (req, res, next) => {
  try {
    const { email } = validateForgotPassword(req.body);
    const user = await prisma.user.findUnique({ where: { email }, select: { id: true, email: true } });

    // Resposta genérica para não revelar se o e-mail está cadastrado.
    if (user) {
      const rawToken = randomBytes(32).toString("hex");
      const tokenHash = createHash("sha256").update(rawToken).digest("hex");
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
      await prisma.passwordReset.updateMany({
        where: { userId: user.id, usedAt: null },
        data: { usedAt: new Date() },
      });
      await prisma.passwordReset.create({ data: { userId: user.id, tokenHash, expiresAt } });
      const baseUrl = process.env.APP_RESET_URL || "educamais://reset-password";
      const resetUrl = `${baseUrl}${baseUrl.includes("?") ? "&" : "?"}token=${rawToken}`;
      await sendResetEmail(user.email, resetUrl);

      // Facilita testes locais. Nunca disponibiliza o token em produção.
      if (process.env.NODE_ENV !== "production" && !process.env.RESEND_API_KEY) {
        res.json({ message: "Se a conta existir, enviaremos as instruções.", developmentResetToken: rawToken });
        return;
      }
    }
    res.json({ message: "Se a conta existir, enviaremos as instruções." });
  } catch (err) {
    next(err);
  }
};

export const resetPassword: RequestHandler = async (req, res, next) => {
  try {
    const { token, password } = validateResetPassword(req.body);
    const tokenHash = createHash("sha256").update(token).digest("hex");
    const reset = await prisma.passwordReset.findUnique({ where: { tokenHash } });
    if (!reset || reset.usedAt || reset.expiresAt <= new Date()) {
      throw new AppError(400, "INVALID_RESET_TOKEN", "Link inválido ou expirado.");
    }

    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.$transaction([
      prisma.user.update({ where: { id: reset.userId }, data: { passwordHash } }),
      prisma.passwordReset.update({ where: { id: reset.id }, data: { usedAt: new Date() } }),
      prisma.passwordReset.updateMany({
        where: { userId: reset.userId, usedAt: null, id: { not: reset.id } },
        data: { usedAt: new Date() },
      }),
    ]);
    res.json({ message: "Senha redefinida com sucesso." });
  } catch (err) {
    next(err);
  }
};
