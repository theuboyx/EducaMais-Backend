import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Button } from '../components/Button';
import { TextField } from '../components/TextField';
import type { AuthStackParamList } from '../navigation/types';
import { authService } from '../services/authService';
import { colors, fonts } from '../theme';
import { validateConfirmPassword, validateNewPassword } from '../utils/validation';

type Props = NativeStackScreenProps<AuthStackParamList, 'ResetPassword'>;

export function ResetPasswordScreen({ route, navigation }: Props) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string>();
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit() {
    const passwordError = validateNewPassword(password);
    const confirmError = validateConfirmPassword(confirm, password);
    if (passwordError || confirmError) {
      setError(passwordError || confirmError);
      return;
    }
    if (!route.params?.token) {
      setError('O link não contém um token válido. Solicite uma nova recuperação.');
      return;
    }
    setLoading(true);
    setError(undefined);
    try {
      await authService.resetPassword(route.params.token, password);
      setDone(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Não foi possível redefinir a senha.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.container}>
            <Text style={styles.title}>{done ? 'Senha atualizada!' : 'Criar nova senha'}</Text>
            <Text style={styles.subtitle}>
              {done ? 'Sua senha foi redefinida. Agora você já pode entrar na sua conta.' : 'Escolha uma senha com pelo menos 8 caracteres.'}
            </Text>
            {!done && (
              <>
                <TextField label="Nova senha" value={password} onChangeText={setPassword} isPassword autoCapitalize="none" />
                <TextField label="Confirmar nova senha" value={confirm} onChangeText={setConfirm} isPassword autoCapitalize="none" />
              </>
            )}
            {!!error && <Text style={styles.error} accessibilityRole="alert">{error}</Text>}
            <Button title={done ? 'Voltar ao login' : 'Redefinir senha'} onPress={() => done ? navigation.navigate('Login') : submit()} loading={loading} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  container: { width: '100%', maxWidth: 420, alignSelf: 'center' },
  title: { fontFamily: fonts.bold, fontSize: 24, color: colors.text },
  subtitle: { fontFamily: fonts.regular, fontSize: 14, color: colors.textMuted, marginTop: 8, marginBottom: 24 },
  error: { fontFamily: fonts.medium, fontSize: 13, color: colors.error, marginBottom: 12 },
});
