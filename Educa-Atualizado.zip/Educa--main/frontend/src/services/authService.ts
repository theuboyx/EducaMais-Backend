import { Platform } from 'react-native';

export type AccountRole = 'aluno' | 'professor';
export type Credentials = { email: string; password: string };
export type SignUpData = { role: AccountRole; name: string; email: string; password: string };
export type AuthUser = { id: string; name: string; email: string; role: AccountRole };
export type AuthSession = { accessToken: string; tokenType: 'Bearer'; expiresIn: number; user: AuthUser };

export class InvalidCredentialsError extends Error {}
export class ApiError extends Error {
  constructor(message: string, public readonly status: number, public readonly code?: string) {
    super(message);
  }
}

const configuredUrl = process.env.EXPO_PUBLIC_API_URL?.trim();
const defaultUrl = Platform.OS === 'android' ? 'http://10.0.2.2:3000' : 'http://localhost:3000';
const API_BASE_URL = (configuredUrl || defaultUrl).replace(/\/+$/, '');
let accessToken: string | undefined;

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...options.headers,
      },
    });
  } catch {
    throw new Error('Não foi possível conectar à API. Confira a URL e se o backend está ligado.');
  }

  const payload = await response.json().catch(() => ({})) as {
    error?: { code?: string; message?: string; fields?: Record<string, string> };
  } & T;

  if (!response.ok) {
    if (response.status === 401 && payload.error?.code === 'INVALID_CREDENTIALS') {
      throw new InvalidCredentialsError(payload.error.message || 'E-mail ou senha incorretos.');
    }
    const message = payload.error?.fields
      ? Object.values(payload.error.fields).join('\n')
      : payload.error?.message || 'Ocorreu um erro na solicitação.';
    throw new ApiError(message, response.status, payload.error?.code);
  }
  return payload;
}

export const authService = {
  async signIn(credentials: Credentials): Promise<AuthSession> {
    const session = await request<AuthSession>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: credentials.email.trim().toLowerCase(), password: credentials.password }),
    });
    accessToken = session.accessToken;
    return session;
  },

  async signUp(data: SignUpData): Promise<{ user: AuthUser }> {
    return request<{ user: AuthUser }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ ...data, email: data.email.trim().toLowerCase() }),
    });
  },

  async requestPasswordReset(email: string): Promise<{ message: string; developmentResetToken?: string }> {
    return request('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email: email.trim().toLowerCase() }),
    });
  },

  async resetPassword(token: string, password: string): Promise<{ message: string }> {
    return request('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, password }),
    });
  },

  async getCurrentUser(): Promise<AuthUser> {
    return request('/auth/me');
  },

  signOut() {
    accessToken = undefined;
  },

  getApiBaseUrl() {
    return API_BASE_URL;
  },
};
